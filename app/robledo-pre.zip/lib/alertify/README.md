alertify.js-shim
================

A shim repo for [alertify.js](https://github.com/fabien-d/alertify.js). This allows package manager (e.g. Bower) to install only the needed files.
